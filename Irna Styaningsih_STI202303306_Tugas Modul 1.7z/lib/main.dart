import 'package:flutter/material.dart';

void main() => runApp(const BasicWidgetsApp());

class BasicWidgetsApp extends StatelessWidget {
  const BasicWidgetsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Basic Widgets Demo',
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      home: const MainPage(),
    );
  }
}

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Basic Widgets'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildMenuCard(
            context,
            'Hello World',
            'Widget Text sederhana',
            Icons.text_fields,
            const HelloWorldPage(),
          ),
          _buildMenuCard(
            context,
            'Widget Column',
            'Layout vertikal',
            Icons.view_column,
            const ColumnWidgetPage(),
          ),
          _buildMenuCard(
            context,
            'Widget Row',
            'Layout horizontal',
            Icons.view_week,
            const RowWidgetPage(),
          ),
          _buildMenuCard(
            context,
            'StatelessWidget vs StatefulWidget',
            'Perbedaan widget statis dan dinamis',
            Icons.compare_arrows,
            const WidgetComparisonPage(),
          ),
          _buildMenuCard(
            context,
            'Membuat Form',
            'Input form dengan validasi',
            Icons.edit_note,
            const FormPage(),
          ),
          _buildMenuCard(
            context,
            'Pemisahan Widget ke dalam Class',
            'Best practice widget composition',
            Icons.class_,
            const WidgetSeparationPage(),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    Widget page,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Icon(icon, size: 40, color: Colors.teal),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () =>
            Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }
}

// 1. Hello World Page
class HelloWorldPage extends StatelessWidget {
  const HelloWorldPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hello World')),
      body: const Center(
        child: Text(
          'Hello World!',
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

// 2. Column Widget Page
class ColumnWidgetPage extends StatelessWidget {
  const ColumnWidgetPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Widget Column')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              color: Colors.red,
              child: const Center(child: Text('Box 1')),
            ),
            const SizedBox(height: 10),
            Container(
              width: 100,
              height: 100,
              color: Colors.green,
              child: const Center(child: Text('Box 2')),
            ),
            const SizedBox(height: 10),
            Container(
              width: 100,
              height: 100,
              color: Colors.blue,
              child: const Center(child: Text('Box 3')),
            ),
          ],
        ),
      ),
    );
  }
}

// 3. Row Widget Page
class RowWidgetPage extends StatelessWidget {
  const RowWidgetPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Widget Row')),
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              color: Colors.purple,
              child: const Center(child: Text('Box 1')),
            ),
            const SizedBox(width: 10),
            Container(
              width: 100,
              height: 100,
              color: Colors.orange,
              child: const Center(child: Text('Box 2')),
            ),
            const SizedBox(width: 10),
            Container(
              width: 100,
              height: 100,
              color: Colors.pink,
              child: const Center(child: Text('Box 3')),
            ),
          ],
        ),
      ),
    );
  }
}

// 4. Widget Comparison Page
class WidgetComparisonPage extends StatelessWidget {
  const WidgetComparisonPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('StatelessWidget vs StatefulWidget')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'StatelessWidget',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const StatelessExample(),
          const SizedBox(height: 24),
          const Text(
            'StatefulWidget',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const StatefulExample(),
        ],
      ),
    );
  }
}

class StatelessExample extends StatelessWidget {
  const StatelessExample({super.key});

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'Ini adalah StatelessWidget. Widget ini tidak bisa berubah setelah dibuat.',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}

class StatefulExample extends StatefulWidget {
  const StatefulExample({super.key});

  @override
  State<StatefulExample> createState() => _StatefulExampleState();
}

class _StatefulExampleState extends State<StatefulExample> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              'Counter: $_counter',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () => setState(() => _counter++),
              child: const Text('Tambah'),
            ),
            const Text(
              'StatefulWidget bisa berubah dan memiliki state internal.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// 5. Form Page
class FormPage extends StatefulWidget {
  const FormPage({super.key});

  @override
  State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Membuat Form')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Nama Lengkap',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Nama tidak boleh kosong';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.email),
              ),
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Email tidak boleh kosong';
                }
                if (!value.contains('@')) {
                  return 'Email tidak valid';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _phoneController,
              decoration: const InputDecoration(
                labelText: 'Nomor Telepon',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.phone),
              ),
              keyboardType: TextInputType.phone,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Nomor telepon tidak boleh kosong';
                }
                return null;
              },
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Data Tersimpan'),
                      content: Text(
                        'Nama: ${_nameController.text}\n'
                        'Email: ${_emailController.text}\n'
                        'Telepon: ${_phoneController.text}',
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('OK'),
                        ),
                      ],
                    ),
                  );
                }
              },
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}

// 6. Widget Separation Page
class WidgetSeparationPage extends StatelessWidget {
  const WidgetSeparationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pemisahan Widget')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Best Practice: Pisahkan widget ke dalam class terpisah',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          const CustomCard(
            title: 'Card 1',
            description: 'Ini adalah custom widget yang reusable',
            icon: Icons.star,
            color: Colors.blue,
          ),
          const CustomCard(
            title: 'Card 2',
            description: 'Kode lebih bersih dan mudah dikelola',
            icon: Icons.favorite,
            color: Colors.red,
          ),
          const CustomCard(
            title: 'Card 3',
            description: 'Widget dapat digunakan berkali-kali',
            icon: Icons.thumb_up,
            color: Colors.green,
          ),
        ],
      ),
    );
  }
}

class CustomCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final Color color;

  const CustomCard({
    super.key,
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color,
          child: Icon(icon, color: Colors.white),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(description),
      ),
    );
  }
}
